package bouncingball;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Syed Shehroz Sohail
 */
public class NewBall implements KeyListener{

    BallView ballView;
    
     NewBall(BallView bv) {
        ballView=bv;
    }

  

    
    @Override
    public void keyTyped(KeyEvent e) {    }

    @Override
    public void keyPressed(KeyEvent e) {        if (e.getKeyChar()==' ') {
            if (BallView.count<20) {

            ballView.createBall();
            BallMovementCtrl ballController=new BallMovementCtrl(ballView);
            BallView.count++;
            ballView.repaint();
            Thread thread=new Thread(ballController);
            thread.start();
            ballView.revalidate();
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {    }
    
}
