/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingball;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.swing.JFrame;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class BallArena {
    JFrame frame;
 NewBall newBall;
 BallView ballView;
 BallMovementCtrl ballController;
    public BallArena() {
        initGUI();
    }

    private void initGUI() {
       
        frame=new JFrame("Game");
        ballView=new BallView();
        ballView.createBall();
        ballController=new BallMovementCtrl(ballView);
        BallView.count++;
        newBall=new NewBall(ballView);
        ballView.setVisible(true);
        frame.add(ballView);
        frame.addKeyListener(newBall);
        Thread thread=new Thread(ballController);
        thread.start();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(Toolkit.getDefaultToolkit().getScreenSize().width,Toolkit.getDefaultToolkit().getScreenSize().height);
        frame.setLocation(0, 0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    
}
