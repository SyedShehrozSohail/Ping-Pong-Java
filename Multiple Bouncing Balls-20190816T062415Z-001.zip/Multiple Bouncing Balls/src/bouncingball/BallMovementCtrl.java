/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingball;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class BallMovementCtrl implements Runnable  {
    Random rand = new Random();
    BallView ball;
    int count=BallView.count;
    int minX, minY, maxX, maxY;
    Dimension  screen;
    int screenWidth,screenHeight;
    boolean left=false,right=true,up=false,down=true;
    int xSpeed=1,ySpeed=2;
    public BallMovementCtrl(BallView v) {
        this.ball=v;
        screen =Toolkit.getDefaultToolkit().getScreenSize();
        screenWidth=(int)screen.getWidth();
        screenHeight=(int)screen.getHeight();
        minY=0;
        minX=0;
        maxX=screenWidth;
        maxY=screenHeight-80;
    }
    @Override
    public void run() {
        while(true)
        {
            if(down)
            {
                if(ball.ballView.get(count).gety()>=maxY)
                {
                    ySpeed=-ySpeed;
                    up=true;
                    down=false;
                }
            }
            if(up)
            {
                if(ball.ballView.get(count).gety()<=minY)
                {
                    ySpeed=-ySpeed;
                    up=false;
                    down=true;
                }
            }
             if(right)
            {
                if(ball.ballView.get(count).getx()>=maxX)
                {
                    xSpeed=-xSpeed;
                    left=true;
                    right=false;
                }
            }
            if(left)
            {
                if(ball.ballView.get(count).getx()<=minX)
                {
                    xSpeed=-xSpeed;
                    left=false;
                    right=true;
                }
            }
            ball.ballView.get(count).sety(ball.ballView.get(count).gety()+ySpeed);
            ball.ballView.get(count).setx(ball.ballView.get(count).getx()+xSpeed);
            ball.repaint();
            ball.revalidate();
            try {
                Thread.sleep(2);
            } catch (InterruptedException ex) {            }
        }
    }
}

