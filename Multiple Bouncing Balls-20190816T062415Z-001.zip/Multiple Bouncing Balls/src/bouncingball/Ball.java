/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingball;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class Ball {
    int x,y;
    public Ball(int xx, int yy)
    {
        this.x=xx;
        this.y=yy;
    }
    public void setx(int xx){
        this.x=xx;
    }
    public void sety(int yy)
    {
        this.y=yy;
    }
    public int getx()
    {
        return this.x;
    }
    public int gety()
    {
        return this.y;
    }
}
