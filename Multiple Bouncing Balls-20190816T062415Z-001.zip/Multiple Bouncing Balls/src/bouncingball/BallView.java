/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingball;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JPanel;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class BallView extends JPanel{
    static int count=0;
    int red,green,blue=0;
    ArrayList<Ball> ballView=new ArrayList<>();
    ArrayList<Color> color=new ArrayList<>();
    Random rand;
    public BallView() {
       ballView.add(new Ball(20,20));
    }
public void createBall()
{
    rand=new Random();
    ballView.add(new Ball(rand.nextInt(800),rand.nextInt(800)));
    createColor();
    color.add(new Color(red,green,blue));
}
public void createColor()
{
    red=rand.nextInt(255);
    green=rand.nextInt(255);
    blue=rand.nextInt(255);
}
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); //To change body of generated methods, choose Tools | Templates.
        for (int i = 0; i <count; i++) 
        {
            g.setColor(color.get(i));
            g.fillOval(ballView.get(i).x, ballView.get(i).y, 30,30);
        }
        
    }
    
   
}
